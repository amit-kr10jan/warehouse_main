import React, { Component } from "react"; 
import UserForm from './userForm';


export default class PopupForm extends Component { 
      constructor(props){
        super(props);
        console.log("userform props====",props.user)
      }

      componentDidMount(){

        console.log('componentDidMount  PopupForm', this.props);
        // if(this.props!==undefined){
        //   var modal = document.getElementById("myModal");
        //   var btn = document.getElementById("myBtn");
        //   var span = document.getElementsByClassName("close")[0];
        //   modal.style.display = "block";
        //   span.onclick = function() {
        //     modal.style.display = "none";
        //   }
        // }
      }

      /* This lifecycle hook gets executed when the component mounts */
    componentWillReceiveProps(nextProps) {
       console.log('componentWillReceiveProps  PopupForm', nextProps);
       if(this.props!==undefined){
        var modal = document.getElementById("myModal");
        var btn = document.getElementById("myBtn");
        var span = document.getElementsByClassName("close")[0];
        if(!nextProps.action){
          modal.style.display = "none";
        }else{
          modal.style.display = "block";
        }
        
        span.onclick = function() {
           modal.style.display = "none";
        }
      }
  
     }

      openPopup=()=>{
       
        var modal = document.getElementById("myModal");
        var btn = document.getElementById("myBtn");
        var span = document.getElementsByClassName("close")[0];
        btn.onclick = function() {
          modal.style.display = "block";
        }
        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
          modal.style.display = "none";
        }
        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
          if (event.target === modal) {
            modal.style.display = "none";
          }
        }
      }

      onSucessupdateUserlist(e){
        if(e){
            alert("User successfully saved !");
            // const {fetchUserHandler} = this.props;
            // fetchUserHandler();
        }
        
    }

      render(){
        return(
               <div className="">
                  
                      <div id="myModal" class="modal">
                          <div class="modal-content">
                            <span class="close">&times;</span>
                              <UserForm user={this.props.user} addUserhanlder={this.props.addUserhanlder} updateUserList={this.onSucessupdateUserlist.bind(this)} />
                          </div> 
                        </div>

                        {/* {this.state.clicked  && <PopupForm  user={this.state.rowData}/>} */}
                </div>
        )
      }
}
