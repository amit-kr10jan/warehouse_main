import React, {Component} from 'react';  
import Input from '../form-container/Input'; 
import Button from '../form-container/Button'
import Select from '../form-container/Select';
import { v4 as uuidv4 } from 'uuid';

class UserForm extends Component {  
  constructor(props) {
    super(props);
    console.log("pros customer",props)
    this.state = {
      // user:props.user.user,
      // role: props.user.role,
      // errors:props.user.errors
      user: {
        id:'',
        name:'',
        password:'',
        role:'',
        email:'',
        phone:'',
        address:'',
        state:'',
        city:'',
        postalCode:'',
        country:''
  },
  role: ['SuperAdmin','admin', 'vendor', 'salesManger'],
  errors:{ 
        name:'',
        password:'',
        role:'',
        email:'',
        phone:'',
        address:'',
        state:'',
        city:'',
        postalCode:'',
        country:''
    },
    }
    this.formIsValid =false;
    this.handleFormSubmit = this.handleFormSubmit.bind(this);
    this.handleInput = this.handleInput.bind(this);
    
  }

   handleInput(e) {
    // let value = e.target.value;
    // this.setState( prevState => ({ productnew : 
    //      {...prevState.productnew, name: value
    //      }
    //    }), () => console.log("name",this.state.productnew))
    // if(!this.validateInputFiled(e)){
    //   alert("plese input valid input")
    //   return false;
    // }else{
      this.validateInputFiled(e);
      //console.log("e.target.name  ", e.target.name);
      let nameID=e.target.name
      let value = e.target.value;
    //  let statusCopy = Object.assign({}, this.state.user);
      let user = this.state.user;
     
      user[nameID] = value;
       this.setState({user}, ()=> {
       console.log("Input change==",this.state)
    })
    //  statusCopy.user[nameID]=value;
      //this.setState(user[nameID]:value);
      //console.log("name",this.state);
    //}
   
  }
  
  isInt(n){
    return Number(n) === n && n % 1 === 0;
}



checkString=(val,len,check)=>{

 // if(isNaN(val)){
     
     if((val.length >0 && val.length >len )){
      return {status:false,message:`Please enter less than ${len} character value` }
     }else{
       return {status:true,message:''}
     }
     
  // }else{
  //   return {status:false,message:`Please enter string charactor`}
  // }
}

checkNumber=(val,len,check)=>{

  if(!isNaN(val)){
      if(val.length!==len){
        return {status:false,message:`Value should be ${len} character`}
      }else{
            if((val.length >0 && val.length >len )){
              return {status:false,message:`Please enter less than ${len}`}
            }else{
              return {status:true,message:''}
            }
          }
    
     
  }else{
    return {status:false,message:`Please enter Integer values`}
  }
}
 

 validateEmail(inputText){
   var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
   if(inputText.match(mailformat)){
    return {status:true,message:''}
   }else{
    return {status:false,message:`You have entered an invalid email address!`}

   }
}



  validateInputFiled=(event)=>{
    event.preventDefault();
    //this.formIsValid = true;
    const { name, value } = event.target;
    let errors = this.state.errors;
    console.log(" event.target ",  event.target.name)
    let msg={}
    switch (name) {
      case 'name': 
            msg = this.checkString(value,10,false)
            errors['name'] = msg.message;
            this.formIsValid=msg.status
            break;
      case 'password': 
           
            msg = this.checkString(value,10,false)
            errors.password = msg.message;
            this.formIsValid=msg.status
            
            
            break;
       case 'email': 
           
            msg = this.validateEmail(value)
            errors.email = msg.message;
            this.formIsValid=msg.status
            
            
            break;
      case 'phone': 
            msg = this.checkNumber(value,10,true)
            errors['phone'] = msg.message;
            this.formIsValid=msg.status
            break;
     case 'postalCode': 
           
            msg = this.checkNumber(value,6,true)
            errors['postalCode'] = msg.message;
            this.formIsValid=msg.status;
            break;
      case 'address': 
            msg = this.checkString(value,100,false)
            errors['address'] = msg.message;
            this.formIsValid=msg.status
            break;
      case 'state': 
            
            msg = this.checkString(value,20,false)
            errors['state'] = msg.message;
            this.formIsValid=msg.status
             break;
      case 'city': 
            
             msg = this.checkString(value,20,false)
             errors['city'] = msg.message;
             this.formIsValid=msg.status
              break;
       case 'country': 
            msg = this.checkString(value,10,false)
            errors['country'] = msg.message;
            this.formIsValid=msg.status
            
            break;
       default:
            break;
    }
    
    // this.setState({errors, [name]: value}, ()=> {
    //     console.log("Errors ==", errors)
    // })
    this.setState({errors }, ()=> {
      console.log("Errors users ==",this.state.errors)
  })
    console.log("Errors stat= formIsValid=",this.formIsValid)
   //return formIsValid;
  }

  /* This lifecycle hook gets executed when the component mounts */
  componentWillReceiveProps(nextProps) {
    //console.log('componentWillReceiveProps', nextProps);
      if (typeof nextProps.user != 'undefined') {
        if(Object.keys(nextProps.user).length === 0){
          
          this.handleClearForm();
          this.setState(prevState => ({
            user: {
              ...prevState.user,
              id:uuidv4(),           
            }
          }), () => console.log("new  key-val ",this.state.user));

        }else{
             this.setState({user: nextProps.user})
        }
      }
    
  
  }
  componentDidMount(){
    const { user} = this.props;
    this.setState({ user:user });
    console.log('componentDidMount', this.state.user);
    if (typeof this.props.user != 'undefined') {
       this.setState({user: this.props.user})
       console.log("copy all other key-val ",this.state.user);
    }else{
      this.setState(prevState => ({
        user: {
          ...prevState.user,
          id:uuidv4(),           
        }
      }), () => console.log("copy all other key-val ",this.state.user));
    }
      
  }

  handleFormSubmit(e) {
      e.preventDefault();
      let userObject = Object.assign({}, this.state);
      if(!this.formIsValid){
        alert("Please enter valid input ")
        return false;
      }else{
        const {addUserhanlder} = this.props;
        console.log("update user data ",userObject.user)
        addUserhanlder(userObject.user).then((res)=>{
          this.props.updateUserList(true)
        });
    }
    //this.handleClearForm(e);
  }   

  handleClearForm(e=null) {
    //  e.preventDefault();
      this.setState({ 
        user: {
          id:'',
          name:'',
          password:'',
          email:'',
          role:'',
          phone:'',
          address:'',
          state:'',
          postalCode:'',
          country:''
    
          }
      })
  }

  render() {
      return (
        <form className="container-fluid" onSubmit={this.handleFormSubmit}>
             <Input inputType={'text'}
                   title= {'User Name'} 
                   name= {'name'}
                   value={this.state.user.name} 
                   placeholder = {'Enter user name'}
                   handleChange = {this.handleInput}
                   errormsg={this.state.errors.name}
                   /> 
               
              <Input inputType={'password'}
                      title= {'Password'} 
                      name= {'password'}
                      value={this.state.user.password} 
                      placeholder = {'Enter user password'}
                      handleChange = {this.handleInput}
                      errormsg={this.state.errors.password}
                      /> {/* customer Name */}
              <Input inputType={'text'}
                    title= {'Email'} 
                    name= {'email'}
                    value={this.state.user.email} 
                    placeholder = {'Enter user email'}
                    handleChange = {this.handleInput}
                    errormsg={this.state.errors.email}
                    /> {/* customer Name */}

              <Select title={'Select Role'}
                    name={'role'}
                    options = {this.state.role} 
                    value = {this.state.user.role}
                    placeholder = {'Select user role'}
                    onChangeUser = {this.handleInput}
                    /> {/* block Selection */}

              {/* <Input inputType={'text'}
                    title= {'Role'} 
                    name= {'role'}
                    value={this.state.user.role} 
                    placeholder = {'Enter user role'}
                    handleChange = {this.handleRole}
                    
                    />  */}

              <Input inputType={'text'}
                    title= {'Phone'} 
                    name= {'phone'}
                    value={this.state.user.phone} 
                    placeholder = {'Enter customer  Phone'}
                    handleChange = {this.handleInput}
                    errormsg={this.state.errors.phone}
                    /> {/*Phone  */}
          
            <Input inputType={'text'}
                    title= {'Address'} 
                    name= {'address'}
                    value={this.state.user.address} 
                    placeholder = {'Enter customer  address'}
                    handleChange = {this.handleInput}
                    errormsg={this.state.errors.address}
                    /> {/*handleAddress  */}
        
              <Input inputType={'text'}
                    title= {'City'} 
                    name= {'city'}
                    value={this.state.user.city} 
                    placeholder = {'Enter customer city'}
                    handleChange = {this.handleInput}
                    errormsg={this.state.errors.city}
                    /> {/* city */}

            
        
              <Input inputType={'text'}
                    title= {'PostalCode'} 
                    name= {'postalCode'}
                    value={this.state.user.postalCode} 
                    placeholder = {'Enter customer PostalCode'}
                    handleChange = {this.handleInput}
                    errormsg={this.state.errors.postalCode}
                    /> {/* PostalCode */}       
         
                <Input inputType={'text'}
                          title= {'State'} 
                          name= {'state'}
                          value={this.state.user.state} 
                          placeholder = {'Enter customer State'}
                          handleChange = {this.handleInput}
                          errormsg={this.state.errors.state}
                  />
                <Input inputType={'text'}
                          title= {'Country'} 
                          name= {'country'}
                          value={this.state.user.country} 
                          placeholder = {'Enter customer Country'}
                          handleChange = {this.handleInput}
                          errormsg={this.state.errors.country}
                          /> {/* Country */}

          

                  <Button 
                      action = {this.handleFormSubmit}
                      type = {'primary'} 
                      title = {'Save'} 
                    style={buttonStyle}
                  /> { /*Submit */ }
                  
                  {/* <Button 
                    action = {this.handleClearForm}
                    type = {'secondary'}
                    title = {'Clear'}
                    style={buttonStyle}
                  />  */}
                  
                  {/* Clear the form */}
          
          </form>
  
      );
   }
}

// const mapStateToProps = state => {
//   const {loading, users: userReducer} = state.userReducer;
//  // const{users:userFormReducer} = state.userFormReducer;
//   console.log("state.userForm ",state);
//  // console.log("userFormReducer ",userFormReducer);
//   return {
//       userReducer,
//       loading,
      
//   }
// };
const buttonStyle = {
  margin : '10px 10px 10px 10px'
}


//export default connect(mapStateToProps)(UserForm);
export default UserForm;