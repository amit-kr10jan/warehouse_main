import React, { Component } from "react"; 
import DataTable from 'react-data-table-component';
import PopupForm from './popupForm';
import './users.css';

export default class UserList extends Component { 
    constructor(props){
        super(props);
        console.log("user props", props);
        this.state = {
            clicked: false,
            rowData:{},
            action:false
        };
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick() {
        this.setState({
          clicked: true
        });
      }
    
    onSucessupdateUserlist(e){
        if(e){
            alert("User successfully saved !");
            // const {fetchUserHandler} = this.props;
            // fetchUserHandler();
        }
        
    }
    componentDidMount(){
            const {fetchUserHandler} = this.props;
            fetchUserHandler();
            // axios.get(`${ROOT_URL}/longcompute`).then((res)=>{
            //     console.log("res", res);
            // })
       
    }
    
    addDetails = () => {
        console.log('Selected Rows: addtDetails ');
        this.setState({
            clicked: true,
            rowData:{},
            action:true
          });
        // <UserForm user={this.props.User} addUserhanlder={this.props.addUserHandler} updateUserList={this.onSucessupdateUserlist.bind(this)} />
    }
    editDetails = (state) => {
        console.log('Selected Rows: editDetails ', state);
        this.setState({
            clicked: true,
            rowData:state,
            action:true
          });
        
    }

    deleteUser = (id) => {
        console.log('Selected Rows deleteUser: ',id);
       // this.clearData();  
        if (window.confirm("Are you sure?")) {  
         this.props.deleteUserHandler(id); 
         this.setState({
            clicked: true,
            rowData:{},
            action:false
          }); 
        }  
      }
     
   
     render(){
        const {userReducer, loading,addUserHandler} = this.props;
        console.log("this.props loading ", this.props);
        const data = userReducer.data;
        
        const columns = [
        {
            name: 'Name',
            selector: 'name',
            sortable: true,
        },
        {
            name: 'Role',
            selector: 'role',
            sortable: true,
            right: true,
        },
        {
            name: 'Email',
            selector: 'email',
            sortable: true,
            right: true,
        },
        {
            name: 'Phone',
            selector: 'phone',
            sortable: true,
            right: true,
        },
        {
            name: 'Pincode',
            selector: 'postalCode',
            sortable: true,
        },
        
        {   name: 'Actions',
            cell: row => <div data-tag="allowRowEvents">
                <div><button className="frm-padding" onClick={() => this.editDetails(row)}><i className="fas fa-edit fa-lg">Edit</i></button>
                     <button className="frm-padding" onClick={() => this.deleteUser(row.sku)}><i className="fas fa-trash fa-lg">Delete</i></button> 
                       
                </div>
                </div>,
        },
        ];


        if(userReducer.length===0){
            return  <div className="card mb-4">
                        <ol className="breadcrumb mb-4">
                            <li className="breadcrumb-item active">Users</li>
                        </ol>
                        <p> Please check network connections!</p>
                   </div>;
        }else{
        return( 
            <div className="container-fluid  bg-col5-product">
                <div className="row ">
                 <div className="col s12 card-body" >
                    {/* <ol className="breadcrumb mb-4">
                                    <li className="breadcrumb-item active">Warehouse</li>
                    </ol> */}
                    
                
                    {/* <ol className="breadcrumb mb-4">
                        <li className="breadcrumb-item active">Users</li>
                    </ol> */}
                    
                    {this.state.clicked  && <PopupForm  user={this.state.rowData} action={this.state.action} addUserhanlder={addUserHandler}/>}
                     
                    {loading  && <p className="txt-align">Loading.... </p>} 
                    
                    {!loading  && 
                       <div className="card-body">
                            <button id="myBtn" className="btn btn-primary addbtn-wdth" onClick={this.addDetails}>Add user</button>
                        <div className="table-responsive"> 
                        <DataTable
                            title="Users List"
                            columns={columns}
                            data={data}
                            pagination
                        />
                            
                        </div>
                    </div>
                    }
                  </div>
                  </div>
                </div>
                
            )
       }
    }
}


