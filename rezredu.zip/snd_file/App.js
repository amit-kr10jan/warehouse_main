import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'; 
//import Login from './components/login/login';
import './App.css';
import Layoutmain from './layout/layout-main';
import HomeLayout from './layout/homeLayout';

const Login =lazy(() => import('./components/login/login'));
const dashboardContainer = lazy(() => import('./containters/homecontainer'));
const Usercontainer =lazy(() => import('./containters/userContainer'));
const VendorList = lazy(()=> import('./containters/vendorListContainer'));
const CustomerList = lazy(()=> import('./containters/customerContainer'));
const productList = lazy(()=> import('./containters/productContainer'));
const categoryList = lazy(()=> import('./containters/categoryContainer'));
const createWarehouseContainer = lazy(()=> import('./containters/createWarehouseContainer'));
const createwarehouseSceneContainer = lazy(()=> import('./containters/createwarehouseSceneContainer'));
const warehouseListContainer = lazy(()=> import('./containters/warehouseListContainer'));
const inventoryContainer = lazy(()=> import('./containters/inventoryContainer'));
const productInventory = lazy(()=> import('./components/inventory/productInventory'));
const warehouseList = lazy(()=> import('./components/warehouse/warehouselist'));
const warehouse = lazy(()=> import('./components/warehouse/warehouse'));
const createWarehouse = lazy(()=> import('./components/warehouse/warehouseInformation'));
const createWarehouseviz= lazy(()=> import('./components/warehouse/createWarehouse'));
const OrderIn = lazy(()=> import('./components/transation/orderin'));
const dashboardComponent = lazy(()=> import('./components/dashboard/dashboard'));
const loginThree = lazy(()=> import('./components/dashboard/loginThree'));
const customGeometory = lazy(()=> import('./components/customvisualization/customGeometory'));

const App = () => (
  <Router>
    <Suspense fallback={<div>Loading...</div>}>
        <Switch>
          <RouteWithLayout exact path="/" layout={AltLayout} component={Login} />
          <RouteWithLayout exact path="/home" layout={HomeLayout} component={warehouseListContainer} />
          <RouteWithLayout exact path="/users" layout={Layoutmain} component={Usercontainer} />
          <RouteWithLayout exact path="/vendors" layout={Layoutmain} component={VendorList} />
          <RouteWithLayout exact path="/customers" layout={Layoutmain} component={CustomerList} />
          <RouteWithLayout exact path="/products" layout={Layoutmain} component={productList} />
          <RouteWithLayout exact path="/categories" layout={Layoutmain} component={categoryList} />
          <RouteWithLayout exact path="/inventory" layout={Layoutmain} component={inventoryContainer} />
          <RouteWithLayout exact path="/warehouselist" layout={Layoutmain} component={warehouseListContainer} />
          <RouteWithLayout exact path="/warehouse" layout={Layoutmain} component={warehouse} />
          <RouteWithLayout exact path="/createwarehouse" layout={Layoutmain} component={createWarehouseContainer} />
          <RouteWithLayout exact path="/createwarehouseviz" layout={Layoutmain} component={createwarehouseSceneContainer} />
          <RouteWithLayout exact path="/dashboard" layout={Layoutmain} component={dashboardContainer} />
          <RouteWithLayout exact path="/dashboards" layout={Layoutmain} component={dashboardComponent} />
          <RouteWithLayout exact path="/threejs" layout={Layoutmain} component={loginThree} />
          <RouteWithLayout exact path="/orderin" layout={Layoutmain} component={OrderIn} />
          <RouteWithLayout exact path="/geometory" layout={Layoutmain} component={customGeometory} />
        </Switch>
    </Suspense>
  </Router>
);

// class App  { 
//   render() { 
//     return ( 
//       <Router>
//       <Suspense fallback={<div>Loading...</div>}>
//         <Switch>
//         <RouteWithLayout exact path="/" layout={AltLayout} component={Login} />
//          <RouteWithLayout exact path="/home" layout={Layoutmain} component={Home} />
//         </Switch>
//       </Suspense>
//     </Router>
//     )
//   }
// } 
export default App;

const RouteWithLayout = ({ component: Component, layout: Layout, ...rest }) => (
  <Route {...rest} render={props => (
      <Layout>
        <Component {...props} />
      </Layout>
  )} />
)



const AltLayout = props => (
  <div>
    {props.children}
  </div>
)
