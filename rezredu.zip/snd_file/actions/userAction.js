import {FETCH_USER_REQUEST,FETCH_USER_SUCCESS,
    FETCH_USER_FAILURE,ADD_USER_REQUEST,ADD_USER_SUCCESS,
    ADD_USER_FAILURE} 
    from '../constaint/userConstaint';
const axios = require('axios');
const ROOT_URL ='http://localhost:3600/api';


export const fetchUserRequest=()=>{
        return{
            type: FETCH_USER_REQUEST
        }
}

export const fetchUserSuccess=(user)=>{
        return{
            type: FETCH_USER_SUCCESS,
            payload:user
        }
}

export const fetchUserFailure=(error)=>{
        return{
            type: FETCH_USER_FAILURE,
            payload:error
        }
}
export const addUserRequest=()=>{
    return{
        type: ADD_USER_REQUEST
    }
}

export const addUserSuccess=(user)=>{
    return{
        type: ADD_USER_SUCCESS,
        payload:user
    }
}

export const addUserFailure=(error)=>{
    return{
        type: ADD_USER_FAILURE,
        payload:error
    }
}

export const fetchUser=()=>{
        return (dispatch)=>{
            dispatch(fetchUserRequest())
            axios.get(`${ROOT_URL}/allusers`)
            .then((response)=>{
                console.log("data", response.data);
                dispatch(fetchUserSuccess(response.data))
            }).catch(error=>{
                console.log("data", error);
                dispatch(fetchUserFailure(error))
            })
        }
}



export const addUser2= (userInfo)=>{
 
    return  (dispatch)=>{
        dispatch(addUserRequest())
        axios.post(`${ROOT_URL}/adduser`,userInfo)
        .then((response)=>{
            console.log(" ha ah  addUser !! response", response)
            dispatch(addUserSuccess(response)).then((res)=>{
                console.log(" ======= addUser !! response", res)
                dispatch(fetchUser());
            });
            
        }).catch(error=>{
            dispatch(addUserFailure(error))
        })
    }
}


export const addUser = (userInfo) => async (dispatch) => {
    const responsePosts = await axios.post(`${ROOT_URL}/adduser`,userInfo).then((res)=>{
                  dispatch(addUserSuccess(responsePosts.data));
    }).catch(err=>{

    });
    
  
    const responseProfile = await axios.get(`${ROOT_URL}/allusers`);
    dispatch(fetchUserSuccess(responseProfile.data));
  
    //dispatch(updateDone());
  };

  export const deleteUser = (userInfo) => async (dispatch) => {
    console.log("delete user call", userInfo)
    const responsePosts = await axios.delete(`${ROOT_URL}/deleteuser?id=${userInfo}`)
        dispatch(addUserSuccess(responsePosts.data));
        
    const responseProfile = await axios.get(`${ROOT_URL}/allusers`);
    dispatch(fetchUserSuccess(responseProfile.data));
  
    //dispatch(updateDone());
  };

  export const updateUser = (userInfo) => async (dispatch) => {
      console.log("update customer ", userInfo)
    const responsePosts = await axios.put(`${ROOT_URL}/updatecustomer`,userInfo);
    dispatch(addUserSuccess(responsePosts.data));
  
    const responseProfile = await axios.get(`${ROOT_URL}/allusers`);
    dispatch(fetchUserSuccess(responseProfile.data));
  
    //dispatch(updateDone());
  };