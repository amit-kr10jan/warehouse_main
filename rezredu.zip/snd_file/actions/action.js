import {ADD_TO_CART,REMOVE_TO_CART,
        FETCH_USER_REQUEST,FETCH_USER_SUCCESS,
        FETCH_USER_FAILURE} from '../constaints';
const axios = require('axios');

export const addToCart=(data)=>{
     //console.log("action data", data)
      return {
          data:data,
          type:ADD_TO_CART
      }
}

export const removeToCart=()=>{
    console.log("action data",)
    return {
        type:REMOVE_TO_CART
    }
}
export const fetchUserRequest=()=>{
    return{
        type: FETCH_USER_REQUEST
    }
}

export const fetchUserSuccess=(user)=>{
    return{
        type: FETCH_USER_SUCCESS,
        payload:user
    }
}

export const fetchUserFailure=(error)=>{
    return{
        type: FETCH_USER_FAILURE,
        payload:error
    }
}

export const fetchUser=()=>{
    return function(dispatch){
         dispatch(fetchUserRequest())
         axios.get('https://jsonplaceholder.typicode.com/users')
          .then((response)=>{
            console.log("data", response.data);
            dispatch(fetchUserSuccess(response.data))
          }).catch(error=>{
            dispatch(fetchUserFailure(error))
          })
    }
}