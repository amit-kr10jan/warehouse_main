import {ADD_USER_REQUEST,ADD_USER_SUCCESS,
    ADD_USER_FAILURE} from '../../constaint/userConstaint';
const axios = require('axios');
const URL='http://localhost:3600/api';


export const addUserRequest=()=>{
        return{
            type: ADD_USER_REQUEST
        }
}

export const addUserSuccess=(user)=>{
        return{
            type: ADD_USER_SUCCESS,
            payload:user
        }
}

export const addUserFailure=(error)=>{
        return{
            type: ADD_USER_FAILURE,
            payload:error
        }
}

export const addUser=(userInfo)=>{
    return function(dispatch){
        dispatch(addUserRequest())
        axios.post(`${URL}/users`,userInfo)
        .then((response)=>{
            console.log("data", response);
            dispatch(addUserSuccess(response))
        }).catch(error=>{
            dispatch(addUserFailure(error))
        })
    }
}



