import { connect } from 'react-redux';
import userlist from '../components/users/userlist';
import {fetchUser,addUser,updateUser,deleteUser} from '../services/actions/userAction';

// const mapStateToProps= state=>({
//      data:state.userReducer
// })
const mapStateToProps = state => {
    const {loading, users: userReducer,User} = state.userReducer;
   // const{users:userFormReducer} = state.userFormReducer;
    console.log("state.userReducer ",state.userReducer.users);
   // console.log("userFormReducer ",userFormReducer);
    return {
        userReducer,
        loading,
        User
        
    }
};
const mapDispatchToProps= dispatch=>({
    fetchUserHandler:data=>dispatch(fetchUser()),
    addUserHandler:data=>dispatch(addUser(data)),
    updateUserHandler:data=>dispatch(updateUser(data)),
    deleteUserHandler:data=>dispatch(deleteUser(data))
})

export default connect(mapStateToProps,mapDispatchToProps)(userlist);
