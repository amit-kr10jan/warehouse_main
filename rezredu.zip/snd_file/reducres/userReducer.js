import {FETCH_USER_REQUEST,FETCH_USER_SUCCESS,
        FETCH_USER_FAILURE,ADD_USER_REQUEST,ADD_USER_SUCCESS,
        ADD_USER_FAILURE} from '../constaint/userConstaint';
import {userFormSchema} from '../constaint/userFormSchema';        

const initialState={
        loading:true,
        users:[],
        error:'',
        User:userFormSchema
    }

export default function userReducer(state=initialState, actions){
 //console.log("reducer data", actions)
 switch(actions.type){
     
    case FETCH_USER_REQUEST:
         return {
             ...state,
             loading:true
         }

    case FETCH_USER_SUCCESS:
         return {
             loading:false,
             users:actions.payload,
             error:'',
             User:userFormSchema
            
         }
    case FETCH_USER_FAILURE:
         return {
             loading:false,
             users:[],
             error:actions.error,
             
         }
    case ADD_USER_REQUEST:
            return {
                ...state,
                loading:true
            }
    
    case ADD_USER_SUCCESS:
            return {
                loading:false,
                users:state.users,
                error:'',
                User:userFormSchema
            }
    case ADD_USER_FAILURE:
            return {
                loading:false,
                users:state.users,
                User:userFormSchema,
                error:actions.error,
                
            }
    default: return state;
 }
}


