import {ADD_TO_CART,REMOVE_TO_CART,
       } from '../constaints';

const initialState={
    loading:false,
     cartData:[],
     error:''

}

export default function cartItems(state=initialState, actions){
    //console.log("reducer data", actions)
    switch(actions.type){
        case ADD_TO_CART:
            return{
                loading:false,
                cartData:actions.data,
                error:'',
            }
        case REMOVE_TO_CART:
             return [
                 ...state,
                 {cartData:actions.data}
             ]
        
        default: return state;
    }
}