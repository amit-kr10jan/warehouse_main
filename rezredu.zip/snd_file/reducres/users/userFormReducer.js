import {ADD_USER_REQUEST,ADD_USER_SUCCESS,
    ADD_USER_FAILURE} from '../../constaint/userConstaint';
const initialState={
     users: {
            id:'',
            name:'',
            password:'',
            role:'',
            email:'',
            phone:'',
            address:'',
            state:'',
            city:'',
            postalCode:'',
            country:''
      },
      role: ['SuperAdmin','admin', 'vendor', 'salesManger'],
      errors:{ 
            name:'',
            password:'',
            role:'',
            email:'',
            phone:'',
            address:'',
            state:'',
            city:'',
            postalCode:'',
            country:''
        },
   
}

export default function userFormReducer(state=initialState, actions){
//  console.log("reducer data", actions)
    switch(actions.type){
    
    case ADD_USER_REQUEST:
        return {
            ...state,
            loading:true
        }

    case ADD_USER_SUCCESS:
        return {
            loading:false,
            users:actions.payload,
            error:'',
            
        }
    case ADD_USER_FAILURE:
        return {
            loading:false,
            users:[],
            error:actions.error,
            
        }
    default: return state;
    }
}

