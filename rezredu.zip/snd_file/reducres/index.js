import {combineReducers} from 'redux';
import cartItems from './reducer';
import userReducer from './userReducer';
import customerReducer from './customer/customerReducer';
import vendorReducer from './vendor/vendorReducer';
import categoryReducer from './category/categoryReducer';
import productReducer from './product/productReducer';
import warehouseReducer from './warehouse/warehouseReducer'
 
export default combineReducers({
    cartItems,userReducer,vendorReducer,customerReducer,
    categoryReducer,productReducer,warehouseReducer
})